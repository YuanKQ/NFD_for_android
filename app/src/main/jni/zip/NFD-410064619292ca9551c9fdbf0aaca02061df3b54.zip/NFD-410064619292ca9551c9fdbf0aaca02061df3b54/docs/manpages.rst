.. _Manpages:

Manpages
========

.. toctree::
   manpages/nfd
   manpages/nfdc
   manpages/nfd-status
   schema
   manpages/nfd-status-http-server
   manpages/ndn-autoconfig
   manpages/ndn-autoconfig.conf
   manpages/ndn-autoconfig-server
   misc/local-prefix-discovery
   manpages/nfd-autoreg
   manpages/ndn-tlv-peek
   manpages/ndn-tlv-poke
   :maxdepth: 1
