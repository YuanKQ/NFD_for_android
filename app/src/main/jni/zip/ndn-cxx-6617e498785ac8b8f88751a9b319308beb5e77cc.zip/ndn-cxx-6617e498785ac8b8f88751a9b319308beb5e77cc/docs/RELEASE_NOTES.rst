Release Notes
+++++++++++++

.. include:: release-notes/release-notes-0.4.0.rst
