ndnsec-unlock-tpm
=================

``ndnsec-unlock-tpm`` is a tool to (temporarily) unlock the **Trusted Platform Module (TPM)** that
manages private keys.

Usage
-----

::

    $ ndnsec-unlock-tpm [-h]

Description
-----------

``ndnsec-unlock-tpm`` will ask for password to unlock the TPM.
